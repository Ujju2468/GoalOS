// -----------------------------------Response1-----------------------------------------------------

import Layout from "../components/layout/Layout";       //Res 2 changed this line.

function Settings() {
  return (
    <Layout>
      <h1>Settings</h1>
    </Layout>
  );
}

export default Settings;
// -----------------------------------Response1-----------------------------------------------------
