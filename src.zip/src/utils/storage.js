// ======================================================
// GoalOS Storage Utility
// Handles all LocalStorage operations
// ======================================================

const STORAGE_KEY = "goalos-data";

// -------------------------------
// Default State
// -------------------------------

const defaultData = {

  completedDays: [],

  notes: {},

  settings: {},

};

// -------------------------------
// Load
// -------------------------------

export function loadData() {

  const data = localStorage.getItem(STORAGE_KEY);

  if (!data) {

    return defaultData;

  }

  return JSON.parse(data);

}

// -------------------------------
// Save
// -------------------------------

export function saveData(data) {

  localStorage.setItem(

    STORAGE_KEY,

    JSON.stringify(data)

  );

}

// -------------------------------
// Completed Days
// -------------------------------

export function getCompletedDays() {

  return loadData().completedDays;

}

export function completeDay(day) {

  const data = loadData();

  if (!data.completedDays.includes(day)) {

    data.completedDays.push(day);

  }

  saveData(data);

}

// -------------------------------
// Notes
// -------------------------------

export function saveNote(day, note) {

  const data = loadData();

  data.notes[day] = note;

  saveData(data);

}

export function getNote(day) {

  return loadData().notes[day] || "";

}

// -------------------------------
// Reset
// -------------------------------

export function clearGoalOS() {

  localStorage.removeItem(STORAGE_KEY);

}